package databasePart1;

import java.sql.*;
import java.util.UUID;
import java.util.List;
import java.util.ArrayList;

import application.User;

/**
 * The DatabaseHelper class is responsible for managing the connection to the database,
 * performing operations such as user registration, login validation, and handling invitation codes.
 */
public class DatabaseHelper {

    // JDBC driver name and database URL 
    static final String JDBC_DRIVER = "org.h2.Driver";   
    static final String DB_URL = "jdbc:h2:~/FoundationDatabase";  

    //  Database credentials 
    static final String USER = "sa"; 
    static final String PASS = ""; 

    private Connection connection = null;
    private Statement statement = null; 

    /**
     * Establishes a connection to the database and creates necessary tables if they do not exist.
     * 
     * @throws SQLException if a database access error occurs
     */
    public void connectToDatabase() throws SQLException {
        try {
            Class.forName(JDBC_DRIVER);
            System.out.println("Connecting to database...");
            connection = DriverManager.getConnection(DB_URL, USER, PASS);
            statement = connection.createStatement(); 
            createTables();
        } catch (ClassNotFoundException e) {
            System.err.println("JDBC Driver not found: " + e.getMessage());
        }
    }

    /**
     * Creates the necessary tables in the database if they do not already exist.
     * 
     * @throws SQLException if a database access error occurs
     */
    private void createTables() throws SQLException {
        // Users table
        String userTable = "CREATE TABLE IF NOT EXISTS cse360users ("
                + "id INT AUTO_INCREMENT PRIMARY KEY, "
                + "userName VARCHAR(255) UNIQUE, "
                + "password VARCHAR(255), "
                + "role VARCHAR(20))";
        statement.execute(userTable);

        // Invitation codes table
        String invitationCodesTable = "CREATE TABLE IF NOT EXISTS InvitationCodes ("
                + "code VARCHAR(10) PRIMARY KEY, "
                + "isUsed BOOLEAN DEFAULT FALSE)";
        statement.execute(invitationCodesTable);

        // Questions table
        String questionsTable = "CREATE TABLE IF NOT EXISTS Questions ("
                + "id INT AUTO_INCREMENT PRIMARY KEY, "
                + "content VARCHAR(1000), "
                + "author VARCHAR(255))";
        statement.execute(questionsTable);

        // Answers table
        String answersTable = "CREATE TABLE IF NOT EXISTS Answers ("
                + "id INT AUTO_INCREMENT PRIMARY KEY, "
                + "content VARCHAR(1000), "
                + "questionId INT, "
                + "author VARCHAR(255))";
        statement.execute(answersTable);

        // Reviews table
        String reviewsTable = "CREATE TABLE IF NOT EXISTS Reviews ("
                + "id INT AUTO_INCREMENT PRIMARY KEY, "
                + "reviewContent VARCHAR(1000), "
                + "reviewer VARCHAR(255), "
                + "targetType VARCHAR(20), "  // "question" or "answer"
                + "targetId INT)";
        statement.execute(reviewsTable);

        // PrivateMessages table
        String messagesTable = "CREATE TABLE IF NOT EXISTS PrivateMessages ("
                + "id INT AUTO_INCREMENT PRIMARY KEY, "
                + "sender VARCHAR(255), "
                + "receiver VARCHAR(255), "
                + "message VARCHAR(1000))";
        statement.execute(messagesTable);
    }

    /**
     * Establishes a connection to the database.
     * 
     * @return a new connection to the database
     * @throws SQLException if a database access error occurs
     */
    protected Connection connect() throws SQLException {
        return DriverManager.getConnection(DB_URL, USER, PASS);
    }

    /**
     * Checks if the database is empty by querying the user table.
     * 
     * @return true if the database has no users, false otherwise
     * @throws SQLException if a database access error occurs
     */
    public boolean isDatabaseEmpty() throws SQLException {
        String query = "SELECT COUNT(*) AS count FROM cse360users";
        ResultSet resultSet = statement.executeQuery(query);
        if (resultSet.next()) {
            return resultSet.getInt("count") == 0;
        }
        return true;
    }

    /**
     * Registers a new user in the database.
     * 
     * @param user the user to be registered
     * @throws SQLException if a database access error occurs
     */
    public void register(User user) throws SQLException {
        String insertUser = "INSERT INTO cse360users (userName, password, role) VALUES (?, ?, ?)";
        try (PreparedStatement pstmt = connection.prepareStatement(insertUser)) {
            pstmt.setString(1, user.getUserName());
            pstmt.setString(2, user.getPassword());
            pstmt.setString(3, user.getRole());
            pstmt.executeUpdate();
        }
    }

    /**
     * Validates the user's login credentials.
     * 
     * @param user the user attempting to log in
     * @return true if the login credentials are valid, false otherwise
     * @throws SQLException if a database access error occurs
     */
    public boolean login(User user) throws SQLException {
        String query = "SELECT * FROM cse360users WHERE userName = ? AND password = ? AND role = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setString(1, user.getUserName());
            pstmt.setString(2, user.getPassword());
            pstmt.setString(3, user.getRole());
            try (ResultSet rs = pstmt.executeQuery()) {
                return rs.next();
            }
        }
    }

    /**
     * Checks if a user with the given username exists in the database.
     * 
     * @param userName the username to check
     * @return true if the user exists, false otherwise
     */
    public boolean doesUserExist(String userName) {
        String query = "SELECT COUNT(*) FROM cse360users WHERE userName = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setString(1, userName);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return rs.getInt(1) > 0;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    /**
     * Retrieves the role of a user by their username.
     * 
     * @param userName the username to look up
     * @return the user's role, or null if the user does not exist
     */
    public String getUserRole(String userName) {
        String query = "SELECT role FROM cse360users WHERE userName = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setString(1, userName);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return rs.getString("role");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * Generates a random invitation code and stores it in the database.
     * 
     * @return the generated invitation code
     */
    public String generateInvitationCode() {
        String code = UUID.randomUUID().toString().substring(0, 4);
        String query = "INSERT INTO InvitationCodes (code) VALUES (?)";
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setString(1, code);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return code;
    }

    /**
     * Validates an invitation code to ensure it is valid and unused.
     * 
     * @param code the invitation code to validate
     * @return true if the code is valid and unused, false otherwise
     */
    public boolean validateInvitationCode(String code) {
        String query = "SELECT * FROM InvitationCodes WHERE code = ? AND isUsed = FALSE";
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setString(1, code);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                markInvitationCodeAsUsed(code);
                return true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    /**
     * Marks the given invitation code as used in the database.
     * 
     * @param code the invitation code to mark as used
     */
    private void markInvitationCodeAsUsed(String code) {
        String query = "UPDATE InvitationCodes SET isUsed = TRUE WHERE code = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setString(1, code);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * Closes the connection and statement objects to release database resources.
     */
    public void closeConnection() {
        try {
            if (statement != null) statement.close();
        } catch (SQLException se2) {
            se2.printStackTrace();
        }
        try {
            if (connection != null) connection.close();
        } catch (SQLException se) {
            se.printStackTrace();
        }
    }

    /**
     * Retrieves all questions from the database.
     * 
     * @return a list of all student questions
     * @throws SQLException if a database access error occurs
     */
    public List<String> getAllStudentQuestions() throws SQLException {
        List<String> questions = new ArrayList<>();
        String query = "SELECT content FROM Questions";
        try (Connection conn = connect();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                questions.add(rs.getString("content"));
            }
        }
        return questions;
    }

    /**
     * Retrieves all answers from the database.
     * 
     * @return a list of all student answers
     * @throws SQLException if a database access error occurs
     */
    public List<String> getAllStudentAnswers() throws SQLException {
        List<String> answers = new ArrayList<>();
        String query = "SELECT content FROM Answers";
        try (Connection conn = connect();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                answers.add(rs.getString("content"));
            }
        }
        return answers;
    }

    /**
     * Retrieves all reviews from the database.
     * 
     * @return a list of all reviews
     * @throws SQLException if a database access error occurs
     */
    public List<String> getAllReviews() throws SQLException {
        List<String> reviews = new ArrayList<>();
        String query = "SELECT reviewer, reviewContent FROM Reviews";
        try (Connection conn = connect();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                reviews.add(rs.getString("reviewer") + ": " + rs.getString("reviewContent"));
            }
        }
        return reviews;
    }

    /**
     * Retrieves all private messages from the database.
     * 
     * @return a list of all private messages
     * @throws SQLException if a database access error occurs
     */
    public List<String> getAllPrivateMessages() throws SQLException {
        List<String> messages = new ArrayList<>();
        String query = "SELECT sender, receiver, message FROM PrivateMessages";
        try (Connection conn = connect();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                messages.add("From " + rs.getString("sender") +
                        " to " + rs.getString("receiver") +
                        ": " + rs.getString("message"));
            }
        }
        return messages;
    }

    /**
     * Sends a private message from one user to another.
     * 
     * @param sender the sender of the message
     * @param receiver the receiver of the message
     * @param message the content of the message
     * @throws SQLException if a database access error occurs
     */
    public void sendPrivateMessage(String sender, String receiver, String message) throws SQLException {
        String query = "INSERT INTO PrivateMessages (sender, receiver, message) VALUES (?, ?, ?)";
        try (Connection conn = connect();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, sender);
            stmt.setString(2, receiver);
            stmt.setString(3, message);
            stmt.executeUpdate();
        }
    }
}
