package application;

import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import databasePart1.*;

import java.sql.SQLException;
import java.util.List;

/**
 * The StaffHomePage class displays the home page for users with the "staff" role.
 * This page implements the staff epics:
 * 1. View all student questions
 * 2. View all student answers
 * 3. View all reviews
 * 4. View private messages between users
 * 5. Send private messages to staff/instructors
 */
public class StaffHomePage {

    private final DatabaseHelper databaseHelper;

    public StaffHomePage(DatabaseHelper databaseHelper) {
        this.databaseHelper = databaseHelper;
    }

    public void show(Stage primaryStage, User currentUser) {
        VBox layout = new VBox(10);
        layout.setPadding(new Insets(20));
        layout.setStyle("-fx-alignment: center-left;");

        Label welcomeLabel = new Label("Welcome, Staff " + currentUser.getUserName());
        welcomeLabel.setStyle("-fx-font-size: 18px; -fx-font-weight: bold;");

        Button viewQuestionsBtn = new Button("View All Student Questions");
        Button viewAnswersBtn = new Button("View All Student Answers");
        Button viewReviewsBtn = new Button("View All Reviews");
        Button viewMessagesBtn = new Button("View Private Messages Between Users");
        Button messageStaffBtn = new Button("Message Other Staff/Instructors");

        TextArea resultArea = new TextArea();
        resultArea.setPrefHeight(250);
        resultArea.setWrapText(true);

        viewQuestionsBtn.setOnAction(e -> {
            try {
                List<String> questions = databaseHelper.getAllStudentQuestions();
                resultArea.setText(String.join("\n\n", questions));
            } catch (SQLException ex) {
                resultArea.setText("Error fetching student questions.");
            }
        });

        viewAnswersBtn.setOnAction(e -> {
            try {
                List<String> answers = databaseHelper.getAllStudentAnswers();
                resultArea.setText(String.join("\n\n", answers));
            } catch (SQLException ex) {
                resultArea.setText("Error fetching student answers.");
            }
        });

        viewReviewsBtn.setOnAction(e -> {
            try {
                List<String> reviews = databaseHelper.getAllReviews();
                resultArea.setText(String.join("\n\n", reviews));
            } catch (SQLException ex) {
                resultArea.setText("Error fetching reviews.");
            }
        });

        viewMessagesBtn.setOnAction(e -> {
            try {
                List<String> messages = databaseHelper.getAllPrivateMessages();
                resultArea.setText(String.join("\n\n", messages));
            } catch (SQLException ex) {
                resultArea.setText("Error fetching messages.");
            }
        });

        messageStaffBtn.setOnAction(e -> {
            TextInputDialog dialog = new TextInputDialog();
            dialog.setTitle("Message Staff/Instructor");
            dialog.setHeaderText("Enter the message to send to staff/instructor");
            dialog.setContentText("Message:");

            dialog.showAndWait().ifPresent(message -> {
                try {
                    databaseHelper.sendPrivateMessage(currentUser.getUserName(), "staff", message);
                    resultArea.setText("Message sent successfully.");
                } catch (SQLException ex) {
                    resultArea.setText("Error sending message.");
                }
            });
        });

        layout.getChildren().addAll(
                welcomeLabel,
                viewQuestionsBtn,
                viewAnswersBtn,
                viewReviewsBtn,
                viewMessagesBtn,
                messageStaffBtn,
                resultArea
        );

        Scene scene = new Scene(layout, 800, 500);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Staff Home Page");
        primaryStage.show();
    }
}
