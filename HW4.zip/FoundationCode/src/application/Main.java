package application;

import databasePart1.DatabaseHelper;

import java.sql.SQLException;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        DatabaseHelper dbHelper = new DatabaseHelper();

        try {
            dbHelper.connectToDatabase();

            // TEST: Register a new user
            User testUser = new User("alice", "pass123", "student");
            if (!dbHelper.doesUserExist(testUser.getUserName())) {
                dbHelper.register(testUser);
                System.out.println("User registered successfully.");
            } else {
                System.out.println("User already exists.");
            }

            // TEST: Login
            boolean loggedIn = dbHelper.login(testUser);
            System.out.println("Login successful? " + loggedIn);

            // TEST: Generate an invitation code
            String code = dbHelper.generateInvitationCode();
            System.out.println("Generated invitation code: " + code);

            // TEST: Validate the code (should be valid once)
            boolean valid = dbHelper.validateInvitationCode(code);
            System.out.println("First validation: " + valid);

            boolean secondTry = dbHelper.validateInvitationCode(code);
            System.out.println("Second validation (should be false): " + secondTry);

            // TEST: View all student questions (assuming data exists)
            List<String> questions = dbHelper.getAllStudentQuestions();
            System.out.println("All Student Questions:");
            for (String q : questions) {
                System.out.println("- " + q);
            }

            // TEST: Send and view private messages
            dbHelper.sendPrivateMessage("staff1", "instructor1", "We need to review question 3.");
            List<String> messages = dbHelper.getAllPrivateMessages();
            System.out.println("Private Messages:");
            for (String msg : messages) {
                System.out.println(msg);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            dbHelper.closeConnection();
        }
    }
}
